<?php
error_reporting(E_ERROR);
//date_default_timezone_set('Asia/Riyadh');
date_default_timezone_set('Africa/Cairo');




$connect = mysql_connect("127.0.0.1","root","");
if($connect)
{
	mysql_select_db("wamtech_db",$connect);
}
else
{
    $connect = mysql_connect("127.0.0.1","root","R1HeK0D8a7R6CIqo");
    mysql_select_db("wamtech_db",$connect);
}
       



mysql_set_charset("UTF8");






function getMacLinux() {
  exec('netstat -ie', $result);
  if(is_array($result)) {
    $iface = array();
    foreach($result as $key => $line) {
      if($key > 0) {
        $tmp = str_replace(" ", "", substr($line, 0, 10));
        if($tmp <> "") {
          $macpos = strpos($line, "HWaddr");
          if($macpos !== false) {
            $iface[] = array('iface' => $tmp, 'mac' => strtolower(substr($line, $macpos+7, 17)));
          }
        }
      }
    }
    return $iface[0]['mac'];
  } else {
    return "notfound";
  }
}
 
function getMacAddress($iv)
{
	return $iv;
}

?>
